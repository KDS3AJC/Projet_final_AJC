const faker = require('faker');
const { it } = require('faker/lib/locales');
faker.setLocale('fr');

describe("Processus création de compte bancaire", () => {

  let firstname = faker.name.firstName()
  let lastname = faker.name.lastName()
  let username = faker.internet.userName()
  let password = faker.internet.password()
  let bankName = faker.company.companyName()
  let routingNumber = faker.finance.routingNumber()
  let accountNumber = faker.finance.routingNumber()

  /*beforeEach(function() {
      cy.signUp(firstname,lastname,username,password);
      cy.wait(5000);
      cy.loginFirstTime(username,password,bankName,routingNumber,accountNumber);
  });*/

  it("Création d'un compte utilisateur")

  it("Vérification balance 0", () => {
     cy.get('[data-test="sidenav-user-balance"]').should('have.text', "$0.00");
  });

  it.only("Vérif si les bank account s'efface",() => {
    cy.login('Katharina_Bernier','s3cret');
    cy.get('[data-test="sidenav-bankaccounts"]').click();
    /*cy.get('[data-test="bankaccount-delete"]').each(($el, index, $list) => {
      $el.click();
    })*/
    cy.get('[data-test="bankaccount-list"]').each(($el) => {
      $el.find('[data-test="bankaccount-delete"]').click()
    })
  })
  
  it("Try to create a new account with name < 5 characters", function () {
		// Remplissage des champs
		cy.get('[name="bankName"]').type("test");
		cy.get('[name="routingNumber"]').type("123456789");
		cy.get('[name="accountNumber"]').type("1234567890");
 
		// Assertion bouton désactivé
		cy.get('[data-test="bankaccount-submit"]').should('be.disabled');
	});
 
	it("Try to create a new account with a Routing Number < 9 digits", function () {
		cy.get('[name="bankName"]').type("Ma Super Banque");
		cy.get('[name="routingNumber"]').type("12345678");
		cy.get('[name="accountNumber"]').type("1234567890");
 
		cy.get('[data-test="bankaccount-submit"]').should('be.disabled');
	});
 
 
	it("Try to create a new account with a Routing Number > 9 digits", function () {	
		cy.get('[name="bankName"]').type("Ma Super Banque");
		cy.get('[name="routingNumber"]').type("1234567890");
		cy.get('[name="accountNumber"]').type("1234567890");
 
		cy.get('[data-test="bankaccount-submit"]').should('be.disabled');
	});
 
	it("Try to create a new account with an Account Number < 9 digits", function () {
		cy.get('[name="bankName"]').type("Ma Super Banque");
		cy.get('[name="routingNumber"]').type("123456789");
		cy.get('[name="accountNumber"]').type("12345678");
 
		cy.get('[data-test="bankaccount-submit"]').should('be.disabled');
	});
 
	it("Try to create a new account with an Account Number > 12 digits", function () {
		cy.get('[name="bankName"]').type("Ma Super Banque");
		cy.get('[name="routingNumber"]').type("123456789");
		cy.get('[name="accountNumber"]').type("1234567890123");
 
		cy.get('[data-test="bankaccount-submit"]').should('be.disabled');
	});
 
	it("Try to create a new account with an Account Number with illegal characters", function () {
		// Test va échouer à cause du mauvais comportement de l'application qui ne devrait accepter que des chiffres
		cy.get('[name="bankName"]').type("Ma Super Banque");
		cy.get('[name="routingNumber"]').type("123456789");
		cy.get('[name="accountNumber"]').type("12345678a");
 
		cy.get('[data-test="bankaccount-submit"]').should('be.disabled');
	});
 
	it("Try to create a new account with an Routing Number with illegal characters", function () {
		// Test va échouer à cause du mauvais comportement de l'application qui ne devrait accepter que des chiffres
		cy.get('[name="bankName"]').type("Ma Super Banque");
		cy.get('[name="routingNumber"]').type("12345678a");
		cy.get('[name="accountNumber"]').type("123456789");
 
		cy.get('[data-test="bankaccount-submit"]').should('be.disabled');
	});








})